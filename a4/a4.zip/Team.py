class Team:
    # add your code here


# test your code above works using this code below
team = Team("Liverpool","Anfield","Liverpool")
print(team.to_string())
print(team.get_name())
print(team.get_stadium())
print(team.get_location())
print(team.set_stadium("MassMutual Anfield"))
print(team.get_stadium())
print(team.to_string())